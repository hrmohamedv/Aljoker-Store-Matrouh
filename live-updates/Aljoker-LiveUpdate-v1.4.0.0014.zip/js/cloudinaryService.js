/**
 * Aljoker Store Matrouh - Cloudinary Cloud Storage & Media Compression Service
 * 
 * Provides:
 * 1. High-speed Client-Side Image Compression (HTML5 Canvas downscaling to ~70-90KB)
 * 2. Direct Unsigned Uploads to Cloudinary CDN (Images & Videos)
 * 3. Video Upload Progress Tracking (0-100%)
 * 4. Graceful Fallback to Compressed Data URLs if network/service is unreachable
 */

const CLOUDINARY_CONFIG = {
  cloudName: "x72ry1iu",
  uploadPreset: "aljoker_store",
  apiBase: "https://api.cloudinary.com/v1_1/x72ry1iu",
  maxImageWidth: 1200,
  maxImageHeight: 1200,
  imageQuality: 0.78,
  maxVideoSizeMb: 35
};

const cloudinaryService = {
  config: CLOUDINARY_CONFIG,

  /**
   * Compresses an image file, blob, or base64 Data URL
   * Scales down large dimensions and compresses to clean JPEG ~75-80% quality.
   */
  async compressImage(fileOrDataUrl, maxWidth = 1200, maxHeight = 1200, quality = 0.78) {
    if (!fileOrDataUrl) return "";

    return new Promise((resolve) => {
      const handleDataUrl = (dataUrl) => {
        if (!dataUrl || typeof dataUrl !== "string" || !dataUrl.startsWith("data:image")) {
          return resolve(dataUrl || "");
        }

        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = () => {
          try {
            let width = img.naturalWidth || img.width;
            let height = img.naturalHeight || img.height;

            if (width > maxWidth || height > maxHeight) {
              const ratio = Math.min(maxWidth / width, maxHeight / height);
              width = Math.round(width * ratio);
              height = Math.round(height * ratio);
            }

            const canvas = document.createElement("canvas");
            canvas.width = Math.max(1, width);
            canvas.height = Math.max(1, height);
            const ctx = canvas.getContext("2d");

            // Fill white background for transparency fallback
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

            const compressed = canvas.toDataURL("image/jpeg", quality);
            resolve(compressed);
          } catch (err) {
            console.warn("Canvas compression failed, falling back to original", err);
            resolve(dataUrl);
          }
        };
        img.onerror = () => resolve(dataUrl);
        img.src = dataUrl;
      };

      if (fileOrDataUrl instanceof Blob || fileOrDataUrl instanceof File) {
        const reader = new FileReader();
        reader.onload = (e) => handleDataUrl(e.target.result);
        reader.onerror = () => resolve("");
        reader.readAsDataURL(fileOrDataUrl);
      } else {
        handleDataUrl(fileOrDataUrl);
      }
    });
  },

  /**
   * Upload an image to Cloudinary with automatic compression and fallback
   * @param {File|Blob|string} imageFileOrDataUrl 
   * @param {string} folder 
   * @param {Function} onProgress 
   * @returns {Promise<string>} Direct HTTPS URL or fallback compressed Data URL
   */
  async uploadImage(imageFileOrDataUrl, folder = "aljoker/uploads", onProgress = null) {
    if (!imageFileOrDataUrl) return "";

    // 1. Compress client-side first
    let compressedDataUrl = "";
    try {
      compressedDataUrl = await this.compressImage(
        imageFileOrDataUrl,
        this.config.maxImageWidth,
        this.config.maxImageHeight,
        this.config.imageQuality
      );
    } catch (_) {
      compressedDataUrl = typeof imageFileOrDataUrl === "string" ? imageFileOrDataUrl : "";
    }

    if (!compressedDataUrl && typeof imageFileOrDataUrl === "string") {
      compressedDataUrl = imageFileOrDataUrl;
    }

    // 2. Upload to Cloudinary Unsigned Endpoint
    try {
      const url = `${this.config.apiBase}/image/upload`;
      const formData = new FormData();
      formData.append("file", compressedDataUrl || imageFileOrDataUrl);
      formData.append("upload_preset", this.config.uploadPreset);
      if (folder) formData.append("folder", folder);

      const uploadedUrl = await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", url, true);
        xhr.timeout = 25000; // 25s timeout

        if (xhr.upload && onProgress) {
          xhr.upload.onprogress = (e) => {
            if (e.lengthComputable) {
              const percent = Math.round((e.loaded / e.total) * 100);
              onProgress(percent);
            }
          };
        }

        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const res = JSON.parse(xhr.responseText);
              resolve(res.secure_url || res.url);
            } catch (err) {
              reject(err);
            }
          } else {
            reject(new Error(`Cloudinary error: ${xhr.status} ${xhr.responseText}`));
          }
        };

        xhr.onerror = () => reject(new Error("Network error during Cloudinary upload"));
        xhr.ontimeout = () => reject(new Error("Timeout during Cloudinary upload"));
        xhr.send(formData);
      });

      console.log("Cloudinary image upload success:", uploadedUrl);
      return uploadedUrl;
    } catch (err) {
      console.warn("Cloudinary upload failed, falling back to local compressed Base64:", err);
      // Fallback: return the compressed Base64 data URL so the user process NEVER fails!
      return compressedDataUrl || (typeof imageFileOrDataUrl === "string" ? imageFileOrDataUrl : "");
    }
  },

  /**
   * Upload video file to Cloudinary with progress tracking
   * @param {File} videoFile 
   * @param {string} folder 
   * @param {Function} onProgress callback(percent: number)
   * @returns {Promise<string>} Direct HTTPS URL
   */
  async uploadVideo(videoFile, folder = "aljoker/videos", onProgress = null) {
    if (!videoFile) return "";

    const sizeMb = videoFile.size / (1024 * 1024);
    if (sizeMb > this.config.maxVideoSizeMb) {
      throw new Error(`حجم الفيديو (${sizeMb.toFixed(1)} MB) أكبر من الحد الأقصى المسموح (${this.config.maxVideoSizeMb} MB). يرجى اختيار فيديو أقصر.`);
    }

    const url = `${this.config.apiBase}/video/upload`;
    const formData = new FormData();
    formData.append("file", videoFile);
    formData.append("upload_preset", this.config.uploadPreset);
    if (folder) formData.append("folder", folder);

    return new Promise((resolve, reject) => {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", url, true);
      xhr.timeout = 180000; // 3 minutes timeout for video

      if (xhr.upload && onProgress) {
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            const percent = Math.round((e.loaded / e.total) * 100);
            onProgress(percent);
          }
        };
      }

      xhr.onload = () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const res = JSON.parse(xhr.responseText);
            console.log("Cloudinary video upload success:", res.secure_url);
            resolve(res.secure_url || res.url);
          } catch (err) {
            reject(err);
          }
        } else {
          try {
            const errRes = JSON.parse(xhr.responseText);
            reject(new Error(errRes.error?.message || `خطأ في رفع الفيديو: ${xhr.status}`));
          } catch (_) {
            reject(new Error(`خطأ في رفع الفيديو: ${xhr.status}`));
          }
        }
      };

      xhr.onerror = () => reject(new Error("انقطع الاتصال أثناء رفع الفيديو. يرجى التحقق من اتصال الإنترنت والمحاولة ثانية."));
      xhr.ontimeout = () => reject(new Error("استغرق رفع الفيديو وقتاً أطول من المسموح. يرجى تجربة فيديو بحجم أصغر."));
      xhr.send(formData);
    });
  }
};

window.cloudinaryService = cloudinaryService;
