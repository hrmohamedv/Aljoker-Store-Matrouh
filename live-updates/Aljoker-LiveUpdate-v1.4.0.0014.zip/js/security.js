/**
 * Al-Joker Store Matrouh - Enterprise Frontend Anti-Tampering & Security Engine.
 * 
 * Provides:
 * 1. DevTools & Debugger Trap Detection
 * 2. Source Inspection Key & Context Menu Blocking
 * 3. Anti-Clickjacking / Frame Hijack Protection
 * 4. Production Console Neutralization (Prevents Token & API Leaks in Logcat)
 * 5. LocalStorage Anti-Tampering & Admin Privilege Verification
 */
(function () {
  'use strict';

  // 1. Block Context Menu (Right Click & Long Press Inspect)
  document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    return false;
  }, { capture: true });

  // 2. Block Inspection & Developer Shortcut Keys
  document.addEventListener('keydown', function (e) {
    // F12 key
    if (e.keyCode === 123) {
      e.preventDefault();
      return false;
    }
    // Ctrl+Shift+I (DevTools), Ctrl+Shift+J (Console), Ctrl+Shift+C (Inspect Element)
    if (e.ctrlKey && e.shiftKey && (e.keyCode === 73 || e.keyCode === 74 || e.keyCode === 67 || e.keyCode === 75)) {
      e.preventDefault();
      return false;
    }
    // Ctrl+U (View Page Source)
    if (e.ctrlKey && e.keyCode === 85) {
      e.preventDefault();
      return false;
    }
    // Ctrl+S (Save Page to Disk)
    if (e.ctrlKey && e.keyCode === 83) {
      e.preventDefault();
      return false;
    }
  }, { capture: true });

  // 3. Anti-Clickjacking / Anti-Iframe Hijacking
  if (window.top !== window.self) {
    try {
      window.top.location = window.self.location;
    } catch (e) {
      document.documentElement.innerHTML = '';
    }
  }

  // 4. Production Console Sanitization (Prevent Sensitive Credential / Token Leaks in Logcat)
  if (typeof window.console !== 'undefined') {
    const noop = function () {};
    const sensitiveMethods = ['log', 'debug', 'info', 'dir', 'table', 'trace'];
    for (let i = 0; i < sensitiveMethods.length; i++) {
      try {
        window.console[sensitiveMethods[i]] = noop;
      } catch (_) {}
    }
  }

  // 5. Anti-Debugging Dynamic Trap (Catches Chrome DevTools / Frida WebView Hooks)
  let debugTriggerCount = 0;
  function runDebuggerTrap() {
    const start = performance.now();
    try {
      // Dynamic evaluation of debugger statement
      (function () {}['constructor']('debugger')());
    } catch (_) {}
    const duration = performance.now() - start;

    // If execution was paused by a debugger breakpoint (> 150ms)
    if (duration > 150) {
      debugTriggerCount++;
      if (debugTriggerCount >= 2) {
        document.documentElement.innerHTML = `
          <div style="background:#080c14;color:#ef4444;height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;font-family:sans-serif;direction:rtl;text-align:center;padding:24px;">
            <div style="font-size:48px;margin-bottom:12px;">🛡️</div>
            <h2 style="margin:0 0 10px;font-size:20px;color:#f87171;">تم تفعيل الحماية الأمنية المشددة</h2>
            <p style="color:#94a3b8;font-size:13px;max-width:320px;line-height:1.6;">تم رصد محاولة غير مصرح بها لتنقيح الشيفرة البرمجية أو فحص الذاكرة. تم إيقاف الجلسة فوراً لحماية أمان الحسابات.</p>
          </div>
        `;
        throw new Error('Debugger execution prevented.');
      }
    } else {
      debugTriggerCount = 0;
    }
  }
  setInterval(runDebuggerTrap, 2500);

  // 6. LocalStorage Anti-Tampering & Session Signature Engine
  window.__JokerSecurity = {
    signData: function (data) {
      if (!data) return '';
      const payload = (data.user_id || '') + ':' +
                      (data.phone_number || '') + ':' +
                      (data.is_admin ? 'ADMIN_ACTIVE' : 'USER_BASIC') +
                      '@JOKER_SEC_ENCLAVE_2026';
      let hash = 0;
      for (let i = 0; i < payload.length; i++) {
        const char = payload.charCodeAt(i);
        hash = ((hash << 5) - hash) + char;
        hash |= 0;
      }
      return 'sec_' + Math.abs(hash).toString(36);
    },

    verifyAndSeal: function (user) {
      if (!user || !user.user_id) return true;
      const expected = this.signData(user);
      const stored = localStorage.getItem('joker_user_sig');

      if (!stored) {
        // Seal initial genuine session
        const origSet = localStorage.__origSet || localStorage.setItem.bind(localStorage);
        origSet('joker_user_sig', expected);
        return true;
      }

      // If localStorage data was tampered with (e.g. is_admin changed via file editor)
      if (stored !== expected) {
        // Clear forged session immediately
        localStorage.removeItem('joker_user');
        localStorage.removeItem('joker_user_sig');
        localStorage.removeItem('joker_admin_token');
        return false;
      }
      return true;
    }
  };

  // Intercept localStorage.setItem to automatically sign legitimate user sessions
  try {
    const originalSetItem = localStorage.setItem.bind(localStorage);
    localStorage.__origSet = originalSetItem;
    localStorage.setItem = function (key, val) {
      originalSetItem(key, val);
      if (key === 'joker_user') {
        try {
          const parsed = JSON.parse(val);
          if (parsed && parsed.user_id) {
            originalSetItem('joker_user_sig', window.__JokerSecurity.signData(parsed));
          }
        } catch (_) {}
      }
    };
  } catch (_) {}

  // Immediate validation of cached user on startup
  try {
    const rawUser = localStorage.getItem('joker_user');
    if (rawUser) {
      const parsed = JSON.parse(rawUser);
      if (!window.__JokerSecurity.verifyAndSeal(parsed)) {
        // Tampering detected!
        window.location.reload();
      }
    }
  } catch (_) {
    localStorage.removeItem('joker_user');
    localStorage.removeItem('joker_user_sig');
  }

})();
