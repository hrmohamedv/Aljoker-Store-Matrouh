/**
 * Aljoker Store Matrouh - Over-The-Air (OTA) Live Update Manager
 * Powered by @capgo/capacitor-updater & Aljoker Isolated Backend API
 * Allows deploying instant UI, feature, and code updates directly to devices without re-installing APK!
 */

const CURRENT_NATIVE_VERSION = "1.4.0.0024";
const STORAGE_KEY_ACTIVE_BUNDLE = "aljoker_active_live_bundle_version";

function getCapacitorUpdater() {
  if (typeof window !== "undefined" && window.Capacitor && window.Capacitor.isNativePlatform()) {
    return window.Capacitor.Plugins?.CapacitorUpdater || null;
  }
  return null;
}

function normalizeBundleUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return "";
  let url = rawUrl.trim();

  // If relative path from our own server (e.g. /uploads/live_updates/...)
  if (url.startsWith("/")) {
    const base = (typeof API_BASE !== "undefined" && API_BASE) ? API_BASE : window.location.origin;
    return `${base}${url}`;
  }

  // 1. Google Drive Share / View URL:
  const gDriveFileMatch = url.match(/drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/i);
  if (gDriveFileMatch && gDriveFileMatch[1]) {
    return `https://drive.google.com/uc?export=download&id=${gDriveFileMatch[1]}`;
  }

  // 2. Google Drive Open URL:
  const gDriveOpenMatch = url.match(/drive\.google\.com\/.*[?&]id=([a-zA-Z0-9_-]+)/i);
  if (gDriveOpenMatch && gDriveOpenMatch[1]) {
    return `https://drive.google.com/uc?export=download&id=${gDriveOpenMatch[1]}`;
  }

  // 3. Dropbox direct download
  if (url.includes("dropbox.com") && url.includes("dl=0")) {
    return url.replace("dl=0", "dl=1");
  }

  // 4. GitHub Release
  const githubTagMatch = url.match(/github\.com\/([^/]+)\/([^/]+)\/releases\/tag\/([^/?#]+)/i);
  if (githubTagMatch) {
    const [, owner, repo, tag] = githubTagMatch;
    const cleanTag = tag.startsWith("v") ? tag : `v${tag}`;
    const fileVer = tag.replace(/^v/i, "");
    return `https://github.com/${owner}/${repo}/releases/download/${cleanTag}/Aljoker-LiveUpdate-v${fileVer}.zip`;
  }

  return url;
}

function compareBundleVersions(v1, v2) {
  if (!v1 && !v2) return 0;
  if (!v1) return -1;
  if (!v2) return 1;

  const clean1 = String(v1).replace(/^v/i, "").trim();
  const clean2 = String(v2).replace(/^v/i, "").trim();

  const parts1 = clean1.split(".").map(n => parseInt(n, 10) || 0);
  const parts2 = clean2.split(".").map(n => parseInt(n, 10) || 0);
  const maxLen = Math.max(parts1.length, parts2.length);

  for (let i = 0; i < maxLen; i++) {
    const num1 = parts1[i] || 0;
    const num2 = parts2[i] || 0;
    if (num1 > num2) return 1;
    if (num1 < num2) return -1;
  }
  return 0;
}

function showLiveUpdateOverlay(targetVersion) {
  let overlay = document.getElementById("live-update-overlay");
  if (!overlay) return;
  overlay.style.display = "flex";

  const iconWrap = document.getElementById("ota-icon-wrap");
  const mainIcon = document.getElementById("ota-main-icon");
  const titleEl = document.getElementById("ota-title");
  const verEl = document.getElementById("ota-target-version");
  const progContainer = document.getElementById("ota-progress-container");
  const percentEl = document.getElementById("ota-progress-percent");
  const actionWrap = document.getElementById("ota-action-wrap");

  if (iconWrap) {
    iconWrap.style.background = "rgba(245,158,11,0.12)";
    iconWrap.style.borderColor = "var(--primary)";
    iconWrap.style.boxShadow = "0 0 35px rgba(245,158,11,0.35)";
    iconWrap.style.color = "var(--primary)";
  }
  if (mainIcon) mainIcon.className = "fa-solid fa-cloud-arrow-down fa-bounce";
  if (titleEl) titleEl.innerHTML = "تحديث هوائي فوري";
  if (verEl) verEl.innerText = `v${targetVersion}`;
  if (progContainer) progContainer.style.display = "block";
  if (percentEl) {
    percentEl.style.display = "block";
    percentEl.style.color = "var(--primary)";
  }
  if (actionWrap) {
    actionWrap.style.display = "none";
    actionWrap.innerHTML = "";
  }

  updateLiveUpdateProgress(15, "تم العثور على تحديث هوائي جديد... جاري تنزيل الملفات");
}

function updateLiveUpdateProgress(percent, text) {
  const bar = document.getElementById("ota-progress-bar");
  const percentEl = document.getElementById("ota-progress-percent");
  const statusEl = document.getElementById("ota-status-text");
  if (bar) bar.style.width = `${percent}%`;
  if (percentEl) percentEl.innerText = `${percent}%`;
  if (statusEl && text) statusEl.innerText = text;
}

function hideLiveUpdateOverlay() {
  const overlay = document.getElementById("live-update-overlay");
  if (overlay) overlay.style.display = "none";
}

function triggerAppRestart(updater) {
  try {
    if (updater && typeof updater.reload === "function") {
      updater.reload().catch(() => window.location.reload());
    } else {
      window.location.reload();
    }
  } catch (_) {
    window.location.reload();
  }
}

async function showLiveUpdateSuccess(targetVersion, updater) {
  const iconWrap = document.getElementById("ota-icon-wrap");
  const mainIcon = document.getElementById("ota-main-icon");
  const titleEl = document.getElementById("ota-title");
  const statusEl = document.getElementById("ota-status-text");
  const bar = document.getElementById("ota-progress-bar");
  const percentEl = document.getElementById("ota-progress-percent");
  const actionWrap = document.getElementById("ota-action-wrap");

  if (iconWrap) {
    iconWrap.style.background = "rgba(16, 185, 129, 0.15)";
    iconWrap.style.borderColor = "#10b981";
    iconWrap.style.boxShadow = "0 0 35px rgba(16, 185, 129, 0.45)";
    iconWrap.style.color = "#10b981";
  }
  if (mainIcon) {
    mainIcon.className = "fa-solid fa-circle-check";
  }
  if (titleEl) {
    titleEl.innerHTML = `<span style="color:#10b981;">تم التحديث بنجاح! 🎉</span>`;
  }
  if (bar) {
    bar.style.width = "100%";
    bar.style.background = "#10b981";
  }
  if (percentEl) {
    percentEl.innerText = "100%";
    percentEl.style.color = "#10b981";
  }

  let secondsLeft = 3;
  const updateCountdownText = () => {
    if (statusEl) {
      statusEl.innerHTML = `
        <div style="font-size:15px; font-weight:700; color:#fff; margin-bottom:6px;">تم التحديث بنجاح وسيتم إعادة تشغيل التطبيق</div>
        <div style="font-size:13px; color:#38bdf8;">إعادة التشغيل تلقائياً خلال <b style="font-size:18px; color:#10b981;">${secondsLeft}</b> ثوانٍ...</div>
      `;
    }
  };
  updateCountdownText();

  let hasRestarted = false;
  const doRestart = () => {
    if (hasRestarted) return;
    hasRestarted = true;
    triggerAppRestart(updater);
  };

  if (actionWrap) {
    actionWrap.style.display = "block";
    actionWrap.innerHTML = `
      <button id="btn-ota-restart-now" style="padding:10px 24px; font-size:14px; font-weight:700; border-radius:10px; background:linear-gradient(135deg, #10b981, #059669); color:#fff; border:none; cursor:pointer; box-shadow:0 4px 15px rgba(16,185,129,0.4); display:inline-flex; align-items:center; gap:8px;">
        <i class="fa-solid fa-rotate-right fa-spin"></i> إعادة التشغيل الآن
      </button>
    `;
    document.getElementById("btn-ota-restart-now")?.addEventListener("click", doRestart);
  }

  const timer = setInterval(() => {
    secondsLeft -= 1;
    if (secondsLeft <= 0) {
      clearInterval(timer);
      doRestart();
    } else {
      updateCountdownText();
    }
  }, 1000);
}

async function checkBundleReachable(url, timeoutMs = 5000) {
  if (!url || typeof url !== "string") return false;

  // On native platform, Capgo native updater operates in Android Java layer (outside WebView).
  // Never let WebView CORS false-positives block valid releases on GitHub or trusted CDNs.
  if (typeof window !== "undefined" && window.Capacitor && window.Capacitor.isNativePlatform()) {
    if (url.includes("github.com") || url.includes("githubusercontent.com") || url.includes("cloudinary.com") || url.includes("drive.google.com")) {
      return true;
    }
  }

  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, {
      method: "HEAD",
      signal: controller.signal
    }).catch(() => null);
    clearTimeout(timer);

    if (res && (res.status === 200 || res.status === 206 || res.status === 302)) {
      return true;
    }

    // Fallback: If HEAD returns 405 (Method Not Allowed) or fails, try lightweight Range GET
    if (res && res.status === 405) {
      const getCtrl = new AbortController();
      const getTimer = setTimeout(() => getCtrl.abort(), timeoutMs);
      const getRes = await fetch(url, {
        method: "GET",
        headers: { "Range": "bytes=0-10" },
        signal: getCtrl.signal
      }).catch(() => null);
      clearTimeout(getTimer);
      return getRes && (getRes.status === 200 || getRes.status === 206);
    }

    // On native platform, if browser fetch failed due to WebView CORS restrictions, let native downloader proceed
    if (typeof window !== "undefined" && window.Capacitor && window.Capacitor.isNativePlatform()) {
      return true;
    }

    return false;
  } catch (_) {
    if (typeof window !== "undefined" && window.Capacitor && window.Capacitor.isNativePlatform()) {
      return true;
    }
    return false;
  }
}

async function showLiveUpdateFailed(reason = "") {
  const iconWrap = document.getElementById("ota-icon-wrap");
  const mainIcon = document.getElementById("ota-main-icon");
  const titleEl = document.getElementById("ota-title");
  const statusEl = document.getElementById("ota-status-text");
  const progContainer = document.getElementById("ota-progress-container");
  const percentEl = document.getElementById("ota-progress-percent");
  const actionWrap = document.getElementById("ota-action-wrap");

  if (iconWrap) {
    iconWrap.style.background = "rgba(245, 158, 11, 0.15)";
    iconWrap.style.borderColor = "#f59e0b";
    iconWrap.style.boxShadow = "0 0 35px rgba(245, 158, 11, 0.4)";
    iconWrap.style.color = "#f59e0b";
  }
  if (mainIcon) {
    mainIcon.className = "fa-solid fa-triangle-exclamation";
  }
  if (titleEl) {
    titleEl.innerHTML = `<span style="color:#f59e0b;">فشل التحديث</span>`;
  }
  if (progContainer) progContainer.style.display = "none";
  if (percentEl) percentEl.style.display = "none";

  let secondsLeft = 2;
  const updateCountdownText = () => {
    if (statusEl) {
      statusEl.innerHTML = `
        <div style="font-size:15px; font-weight:700; color:#fff; margin-bottom:6px;">تعذر استكمال التحديث الهوائي حالياً</div>
        <div style="font-size:13px; color:#cbd5e1;">جاري فتح التطبيق بالنسخة الحالية خلال <b style="font-size:17px; color:#f59e0b;">${secondsLeft}</b> ثوانٍ...</div>
      `;
    }
  };
  updateCountdownText();

  let hasExited = false;
  const exitToApp = () => {
    if (hasExited) return;
    hasExited = true;
    hideLiveUpdateOverlay();
  };

  if (actionWrap) {
    actionWrap.style.display = "block";
    actionWrap.innerHTML = `
      <button id="btn-ota-skip-now" style="padding:9px 22px; font-size:13px; font-weight:700; border-radius:8px; background:rgba(255,255,255,0.08); color:#fff; border:1px solid #475569; cursor:pointer; display:inline-flex; align-items:center; gap:8px;">
        <i class="fa-solid fa-arrow-left"></i> الدخول للتطبيق الآن
      </button>
    `;
    document.getElementById("btn-ota-skip-now")?.addEventListener("click", exitToApp);
  }

  const timer = setInterval(() => {
    secondsLeft -= 1;
    if (secondsLeft <= 0) {
      clearInterval(timer);
      exitToApp();
    } else {
      updateCountdownText();
    }
  }, 1000);
}

async function checkForLiveUpdateStartup() {
  const updater = getCapacitorUpdater();
  if (!updater) {
    console.info("[LiveUpdate] Web / Browser environment detected. OTA check bypassed.");
    return;
  }

  try {
    // 1. Notify native layer that JS started cleanly (prevents rollback)
    await updater.notifyAppReady();
    console.log("[LiveUpdate] Native layer notified: App is ready.");

    // 2. Query active bundle
    let currentVer = CURRENT_NATIVE_VERSION;
    try {
      const current = await updater.current();
      const active = current?.bundle?.version || current?.bundle?.id;
      if (active && active !== "builtin") {
        currentVer = active;
        localStorage.setItem(STORAGE_KEY_ACTIVE_BUNDLE, active);
      } else {
        const stored = localStorage.getItem(STORAGE_KEY_ACTIVE_BUNDLE);
        if (stored && stored !== "builtin") currentVer = stored;
      }
    } catch (e) {
      console.warn("[LiveUpdate] Could not read current bundle info", e);
    }

    // 3. Fetch update config from Firebase RTDB first, then fallback to backend API
    let config = null;
    try {
      const fbRes = await fetch("https://aljoker-store-matrouh-default-rtdb.firebaseio.com/live_updates.json");
      if (fbRes.ok) {
        config = await fbRes.json();
      }
    } catch (_) { }

    if (!config || !config.bundle_url) {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 4000);
        const res = await fetch(`${API_BASE}/api/updates/live?ts=${Date.now()}`, {
          signal: controller.signal
        });
        clearTimeout(timer);
        if (res.ok) {
          config = await res.json();
        }
      } catch (_) { }
    }

    if (!config || !config.enabled || !config.bundle_url) return;

    const targetVersion = (config.bundle_version || "").replace(/^v/i, "").trim();
    if (!targetVersion) return;

    const isNewer = compareBundleVersions(targetVersion, currentVer) > 0;
    if (!isNewer) {
      console.log(`[LiveUpdate] App is up to date (current: v${currentVer}, cloud: v${targetVersion}).`);
      return;
    }

    // 4. Circuit Breaker: Skip if this specific version failed repeatedly in this session
    const failKey = `aljoker_ota_fail_${targetVersion}`;
    const failCount = parseInt(sessionStorage.getItem(failKey) || "0", 10);
    if (failCount >= 5) {
      console.warn(`[LiveUpdate] Skipping OTA v${targetVersion} due to repeated previous failures in this session.`);
      return;
    }

    // 5. Require SHA-256 Checksum (Capgo native strictly throws on missing checksum)
    const checksum = (config.checksum || "").trim();
    if (!checksum || checksum.length < 32) {
      console.warn("[LiveUpdate] Missing or invalid SHA-256 checksum in update config. Bypassing OTA update safely.");
      return;
    }

    // 6. Normalize and validate URL
    let targetUrl = normalizeBundleUrl(config.bundle_url);
    if (!targetUrl || !/^https?:\/\//i.test(targetUrl)) {
      console.warn("[LiveUpdate] Invalid or non-http bundle URL. Automatically canceling OTA update:", config.bundle_url);
      return;
    }

    // 7. Pre-flight Check: Ensure bundle URL is genuinely accessible (prevents 404 / 88% freeze)
    console.log(`[LiveUpdate] Pre-flight checking bundle URL accessibility: ${targetUrl}`);
    let isReachable = await checkBundleReachable(targetUrl, 5000);
    if (!isReachable) {
      // Try local server fallback if primary URL is dead
      const fallbackUrl = (typeof API_BASE !== "undefined" && API_BASE)
        ? `${API_BASE}/uploads/live_updates/Aljoker-LiveUpdate-v${targetVersion}.zip`
        : null;
      if (fallbackUrl && fallbackUrl !== targetUrl && await checkBundleReachable(fallbackUrl, 3000)) {
        console.log(`[LiveUpdate] Primary URL unreachable. Using verified backend fallback: ${fallbackUrl}`);
        targetUrl = fallbackUrl;
        isReachable = true;
      }
    }

    if (!isReachable) {
      console.warn(`[LiveUpdate] Bundle URL returned 404 or unreachable (${targetUrl}). Bypassing OTA update cleanly without freeze.`);
      return;
    }

    // 8. New update found and verified! Show overlay and begin download
    console.log(`[LiveUpdate] Verified live update ready: v${targetVersion}. Starting download...`);
    showLiveUpdateOverlay(targetVersion);

    const downloadOpts = {
      url: targetUrl,
      version: targetVersion,
      checksum: checksum
    };

    let fakeProg = 15;
    let nativeProgressReceived = false;
    const interval = setInterval(() => {
      if (nativeProgressReceived) return;

      if (fakeProg < 70) {
        fakeProg += 4;
      } else if (fakeProg < 80) {
        fakeProg += 1;
      }

      if (fakeProg >= 80) {
        updateLiveUpdateProgress(80, "جاري استكمال التنزيل وتجهيز ملفات التحديث...");
      } else {
        updateLiveUpdateProgress(fakeProg, `جاري تنزيل ملفات التحديث (${fakeProg}%)...`);
      }
    }, 600);

    // Hard failsafe timer: automatically cancel and show failure if taking > 25 seconds
    let failsafeTriggered = false;
    const failsafeTimer = setTimeout(() => {
      failsafeTriggered = true;
      console.warn("[LiveUpdate] Failsafe timeout triggered (25s): canceling update.");
      clearInterval(interval);
      sessionStorage.setItem(failKey, String(failCount + 1));
      showLiveUpdateFailed("استغرقت عملية التنزيل وقتاً أطول من المعتاد");
    }, 25000);

    let downloadedBundle = null;
    let progressListener = null;

    try {
      // Listen to real Capgo native progress if available
      try {
        if (typeof updater.addListener === "function") {
          progressListener = await updater.addListener("download", (status) => {
            if (status && typeof status.percent === "number") {
              nativeProgressReceived = true;
              const p = Math.min(95, Math.max(15, Math.round(status.percent)));
              updateLiveUpdateProgress(p, `جاري تنزيل ملفات التحديث (${p}%)...`);
            }
          });
        }
      } catch (_) {}

      const downloadPromise = updater.download(downloadOpts);
      const downloadTimeout = new Promise((_, reject) => {
        setTimeout(() => reject(new Error("مهلة تنزيل التحديث انتهت")), 25000);
      });
      downloadedBundle = await Promise.race([downloadPromise, downloadTimeout]);
    } finally {
      clearInterval(interval);
      clearTimeout(failsafeTimer);
      if (progressListener && typeof progressListener.remove === "function") {
        try { progressListener.remove(); } catch (_) {}
      }
    }

    if (failsafeTriggered) return;

    updateLiveUpdateProgress(96, "جاري تطبيق التحديث وتثبيت الملفات...");
    try {
      await updater.set({ id: downloadedBundle.id });
    } catch (setErr) {
      await updater.next({ id: downloadedBundle.id });
    }

    localStorage.setItem(STORAGE_KEY_ACTIVE_BUNDLE, targetVersion);

    // Show explicit success with countdown
    await showLiveUpdateSuccess(targetVersion, updater);

  } catch (err) {
    console.warn("[LiveUpdate] OTA check error or aborted:", err);
    const targetVer = (config?.bundle_version || "").replace(/^v/i, "").trim();
    if (targetVer) {
      const fKey = `aljoker_ota_fail_${targetVer}`;
      const c = parseInt(sessionStorage.getItem(fKey) || "0", 10);
      sessionStorage.setItem(fKey, String(c + 1));
    }
    await showLiveUpdateFailed(err?.message || "");
  }
}

// Rollback to built-in bundle
async function rollbackLiveUpdateToBuiltin() {
  const updater = getCapacitorUpdater();
  if (!updater) {
    showToast("خاصية التراجع عن التحديث تعمل على تطبيق الهاتف فقط", "info");
    return;
  }
  showAppConfirm(
    "هل أنت متأكد من رغبتك في إلغاء التحديث والرجوع للإصدار الأصلي المبني داخل التطبيق؟",
    async () => {
      try {
        await updater.reset();
        localStorage.removeItem(STORAGE_KEY_ACTIVE_BUNDLE);
        showToast("تم الرجوع للنسخة الأصلية بنجاح، جاري إعادة التشغيل...", "success");
        setTimeout(() => {
          updater.reload().catch(() => window.location.reload());
        }, 600);
      } catch (err) {
        showToast("تعذر التراجع عن التحديث: " + (err.message || ""), "error");
      }
    },
    "التراجع عن التحديث"
  );
}

