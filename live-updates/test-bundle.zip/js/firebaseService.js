/**
 * Aljoker Store Matrouh - Firebase Realtime Database Cloud Sync Service
 * Connects the app directly to: https://aljoker-store-matrouh-default-rtdb.firebaseio.com
 * Allows storing & syncing users, prices, accounts, descriptions, orders, and live updates in Google Cloud!
 */

const FIREBASE_RTDB_URL = "https://aljoker-store-matrouh-default-rtdb.firebaseio.com";

const firebaseService = {
  url: FIREBASE_RTDB_URL,
  isAvailable: null, // null = unknown, true = connected, false = permission denied / offline

  async testConnection() {
    try {
      const res = await fetch(`${this.url}/app_info.json?ts=${Date.now()}`);
      if (res.status === 200) {
        this.isAvailable = true;
        console.log("☁️ [Firebase Cloud RTDB] Connected successfully to Google Cloud!");
        return true;
      } else if (res.status === 401) {
        this.isAvailable = false;
        console.warn("⚠️ [Firebase Cloud RTDB] 401 Permission Denied. Please enable Read/Write rules in Firebase Console.");
        return false;
      }
    } catch (e) {
      this.isAvailable = false;
      console.warn("⚠️ [Firebase Cloud RTDB] Network offline or unreachable:", e);
      return false;
    }
    return false;
  },

  // 1. Get all store info & contacts
  async getAppInfo() {
    try {
      const res = await fetch(`${this.url}/app_info.json`);
      if (res.ok) return await res.json();
    } catch (e) {}
    return null;
  },

  // 2. Get all products (UC & Wi-Fi)
  async getProducts() {
    try {
      const res = await fetch(`${this.url}/products.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        // Convert object / map to array if necessary
        if (Array.isArray(data)) return data.filter(Boolean);
        return Object.values(data);
      }
    } catch (e) {}
    return null;
  },

  // 3. Update or Save product in Cloud
  async saveProduct(product) {
    try {
      const pid = product.product_id || product.id || Date.now();
      const res = await fetch(`${this.url}/products/${pid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id: pid,
          product_id: pid,
          name: product.name,
          category: product.category,
          price: parseFloat(product.price),
          original_price: (product.original_price !== undefined && product.original_price !== null && product.original_price !== "") ? parseFloat(product.original_price) : null,
          offer_buy_qty: (product.offer_buy_qty !== undefined && product.offer_buy_qty !== null && product.offer_buy_qty !== "") ? parseInt(product.offer_buy_qty, 10) : null,
          offer_free_qty: (product.offer_free_qty !== undefined && product.offer_free_qty !== null && product.offer_free_qty !== "") ? parseInt(product.offer_free_qty, 10) : null,
          details: product.details || "",
          product_code: String(product.product_code || pid),
          auto_code: product.auto_code || "",
          icon: product.icon || (product.category === "WiFi" ? "assets/icons/wifi-ticket.svg" : "assets/icons/uc-stack.svg"),
          is_active: product.is_active !== false
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async deleteProduct(productId) {
    try {
      const res = await fetch(`${this.url}/products/${productId}.json`, {
        method: "DELETE"
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async updateProductPrice(productId, newPrice) {
    try {
      const res = await fetch(`${this.url}/products/${productId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ price: parseFloat(newPrice) })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Sequential atomic-like counters: Products start at 1, wifi follows, new items continue incrementally
  async getNextProductId() {
    try {
      let lastId = 11;
      const res = await fetch(`${this.url}/counters/products_last_id.json?ts=${Date.now()}`);
      if (res.ok) {
        const val = await res.json();
        if (typeof val === "number" && val >= 11) lastId = val;
      }
      const prods = await this.getProducts();
      if (Array.isArray(prods)) {
        for (const p of prods) {
          const num = parseInt(p.product_id || p.id, 10);
          if (!isNaN(num) && num > lastId && num < 1000000) {
            lastId = num;
          }
        }
      }
      const nextId = lastId + 1;
      await fetch(`${this.url}/counters/products_last_id.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextId)
      });
      return nextId;
    } catch (e) {
      return 12;
    }
  },

  // Sequential atomic-like counters: Marketplace starts at 1, new listings continue incrementally
  async getNextMarketplaceId() {
    try {
      let lastId = 12;
      const res = await fetch(`${this.url}/counters/marketplace_last_id.json?ts=${Date.now()}`);
      if (res.ok) {
        const val = await res.json();
        if (typeof val === "number" && val >= 12) lastId = val;
      }
      const items = await this.getMarketplace();
      if (Array.isArray(items)) {
        for (const it of items) {
          const num = parseInt(it.account_id || it.id, 10);
          if (!isNaN(num) && num > lastId && num < 1000000) {
            lastId = num;
          }
        }
      }
      const nextId = lastId + 1;
      await fetch(`${this.url}/counters/marketplace_last_id.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextId)
      });
      return nextId;
    } catch (e) {
      return 13;
    }
  },

  // 4. Get all marketplace accounts & popularity cards
  async getMarketplace() {
    try {
      const res = await fetch(`${this.url}/marketplace.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        if (Array.isArray(data)) return data.filter(Boolean);
        return Object.values(data);
      }
    } catch (e) {}
    return null;
  },

  // 5. Add new account / card to Cloud marketplace
  async addMarketplaceAccount(account) {
    try {
      const aid = account.account_id || Date.now();
      const res = await fetch(`${this.url}/marketplace/${aid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(account)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 6. Update account status
  async updateMarketplaceStatus(accountId, status, extraFields = {}) {
    try {
      const payload = { status, ...(extraFields || {}) };
      const res = await fetch(`${this.url}/marketplace/${accountId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 6.5. Delete account from marketplace
  async deleteMarketplaceAccount(accountId) {
    try {
      const res = await fetch(`${this.url}/marketplace/${accountId}.json`, {
        method: "DELETE"
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 7. Get user by phone number or pubg ID (handles any phone prefix 010 / 10 / +20)
  async getUser(identifier) {
    if (!identifier) return null;
    try {
      const raw = String(identifier).trim();
      const digitsOnly = raw.replace(/[^0-9]/g, "");

      // Normalize common Egyptian phone formats
      let variants = [raw];
      if (digitsOnly) {
        variants.push(digitsOnly);
        if (digitsOnly.startsWith("20") && digitsOnly.length === 12) {
          variants.push("0" + digitsOnly.slice(2));
          variants.push(digitsOnly.slice(2));
        } else if (digitsOnly.startsWith("0") && digitsOnly.length === 11) {
          variants.push(digitsOnly.slice(1));
          variants.push("2" + digitsOnly);
        } else if (!digitsOnly.startsWith("0") && digitsOnly.length === 10) {
          variants.push("0" + digitsOnly);
        }
      }

      // 1. Direct path check on Firebase RTDB
      for (const v of variants) {
        if (!v) continue;
        const res = await fetch(`${this.url}/users/${v}.json`);
        if (res.ok) {
          const u = await res.json();
          if (u && (u.phone_number || u.user_id || u.name)) return u;
        }
      }

      // 2. Query all users from RTDB if direct lookup failed
      const allRes = await fetch(`${this.url}/users.json`);
      if (allRes.ok) {
        const allUsers = await allRes.json();
        if (allUsers) {
          for (const key in allUsers) {
            const u = allUsers[key];
            if (!u) continue;
            const uPhone = String(u.phone_number || key).replace(/[^0-9]/g, "");
            const uPubg = String(u.pubg_id || "").trim();
            for (const v of variants) {
              if (v && (uPhone === v || uPhone.endsWith(v) || v.endsWith(uPhone) || uPubg === v)) {
                return u;
              }
            }
          }
        }
      }
    } catch (e) {
      console.warn("Firebase getUser error:", e);
    }
    return null;
  },

  // 7.5. Update user password in Firebase Realtime Database
  async updateUserPassword(phone, newHashedPassword) {
    try {
      const u = await this.getUser(phone);
      const keyPhone = u?.phone_number ? String(u.phone_number).replace(/[^0-9]/g, "") : String(phone).replace(/[^0-9]/g, "");
      if (!keyPhone) return false;

      const res = await fetch(`${this.url}/users/${keyPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password_hash: newHashedPassword })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Helper: Secure password verification using WebCrypto PBKDF2-SHA256 (identical to backend)
  async verifyPassword(plainPassword, storedHash) {
    if (!storedHash) return false;
    if (storedHash === plainPassword) return true;
    if (!storedHash.includes("$")) return false;
    try {
      const [saltHex, expectedHex] = storedHash.split("$");
      const enc = new TextEncoder();
      const keyMaterial = await crypto.subtle.importKey(
        "raw",
        enc.encode(plainPassword),
        { name: "PBKDF2" },
        false,
        ["deriveBits"]
      );
      const derived = await crypto.subtle.deriveBits(
        {
          name: "PBKDF2",
          salt: enc.encode(saltHex),
          iterations: 200000,
          hash: "SHA-256"
        },
        keyMaterial,
        256
      );
      const hex = Array.from(new Uint8Array(derived))
        .map(b => b.toString(16).padStart(2, "0"))
        .join("");
      return hex === expectedHex;
    } catch (e) {
      console.warn("Password verification error:", e);
      return false;
    }
  },

  // Helper: Secure password hashing using WebCrypto PBKDF2-SHA256
  async hashPassword(plainPassword) {
    const saltBytes = new Uint8Array(16);
    crypto.getRandomValues(saltBytes);
    const saltHex = Array.from(saltBytes).map(b => b.toString(16).padStart(2, "0")).join("");
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey(
      "raw",
      enc.encode(plainPassword),
      { name: "PBKDF2" },
      false,
      ["deriveBits"]
    );
    const derived = await crypto.subtle.deriveBits(
      {
        name: "PBKDF2",
        salt: enc.encode(saltHex),
        iterations: 200000,
        hash: "SHA-256"
      },
      keyMaterial,
      256
    );
    const hashHex = Array.from(new Uint8Array(derived)).map(b => b.toString(16).padStart(2, "0")).join("");
    return `${saltHex}$${hashHex}`;
  },

  // 8. Find user by PUBG ID
  async getUserByPubgId(pubgId) {
    try {
      const cleanId = String(pubgId || "").trim();
      const res = await fetch(`${this.url}/users.json`);
      if (res.ok) {
        const users = await res.json();
        if (!users) return null;
        for (const phone in users) {
          const u = users[phone];
          if (u && String(u.pubg_id).trim() === cleanId) {
            return u;
          }
        }
      }
    } catch (e) {}
    return null;
  },

  // 9. Save or update user
  async saveUser(user) {
    try {
      const cleanPhone = (user.phone_number || "").replace(/[^0-9]/g, "");
      if (!cleanPhone) return false;
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(user)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 10. Update user PUBG ID
  async updateUserPubgId(phone, pubgId) {
    try {
      const cleanPhone = (phone || "").replace(/[^0-9]/g, "");
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pubg_id: String(pubgId).trim() })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 10.1 Check if PUBG ID is already used by another user
  async checkPubgIdExists(pubgId, excludePhone = "") {
    try {
      const targetId = String(pubgId || "").trim();
      if (!targetId) return false;
      const cleanExclude = (excludePhone || "").replace(/[^0-9]/g, "");

      const res = await fetch(`${this.url}/users.json`);
      if (res.ok) {
        const users = await res.json();
        if (users && typeof users === "object") {
          for (const [phoneKey, u] of Object.entries(users)) {
            if (!u) continue;
            const uPhone = String(u.phone_number || phoneKey).replace(/[^0-9]/g, "");
            if (cleanExclude && uPhone === cleanExclude) continue;
            if (u.pubg_id && String(u.pubg_id).trim() === targetId) {
              return true;
            }
          }
        }
      }
    } catch (e) {
      console.warn("checkPubgIdExists error:", e);
    }
    return false;
  },

  // 11. Create new purchase order
  async createOrder(order) {
    try {
      const oid = order.order_id || Date.now();
      order.order_id = oid;
      if (order.is_read_by_admin === undefined) {
        order.is_read_by_admin = false;
      }
      const res = await fetch(`${this.url}/orders/${oid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(order)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 12. Get orders
  async getOrders(userPhone = null) {
    try {
      const res = await fetch(`${this.url}/orders.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        const all = Array.isArray(data) ? data.filter(Boolean) : Object.values(data);
        if (userPhone) {
          const cleanPhone = (userPhone || "").replace(/[^0-9]/g, "");
          return all.filter(o => (o.user_phone || "").replace(/[^0-9]/g, "") === cleanPhone);
        }
        return all;
      }
    } catch (e) {}
    return [];
  },

  // 13. Get Live Update config
  async getLiveUpdateConfig() {
    try {
      const res = await fetch(`${this.url}/live_updates.json`);
      if (res.ok) return await res.json();
    } catch (e) {}
    return null;
  },

  // 14. Save Live Update config
  async saveLiveUpdateConfig(config) {
    try {
      const res = await fetch(`${this.url}/live_updates.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 15. Update user wallet balance directly in Cloud RTDB
  async updateUserBalance(phone, newBalance) {
    try {
      const cleanPhone = (phone || "").replace(/[^0-9]/g, "");
      if (!cleanPhone) return false;
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ wallet_balance: parseFloat(newBalance) })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 15.5. Update user's client app version in Cloud RTDB
  async updateUserAppVersion(phone, appVersion) {
    try {
      const cleanPhone = (phone || "").replace(/[^0-9]/g, "");
      if (!cleanPhone) return false;
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          app_version: appVersion,
          last_active_at: new Date().toISOString()
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 16. Update user KYC / National ID & Biometric Verification in Cloud RTDB
  async updateUserKYC(phone, kycData) {
    try {
      const cleanPhone = (phone || "").replace(/[^0-9]/g, "");
      if (!cleanPhone) return false;
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          is_id_verified: kycData.is_id_verified !== undefined ? kycData.is_id_verified : true,
          national_id: kycData.national_id,
          id_card_image: kycData.id_card_image || kycData.id_card_front || "",
          id_card_front: kycData.id_card_front || kycData.id_card_image || "",
          id_card_back: kycData.id_card_back || "",
          live_selfie_image: kycData.live_selfie_image || "",
          profile_photo: kycData.profile_photo || "",
          match_score: typeof kycData.match_score === "number" ? kycData.match_score : 92,
          kyc_status: kycData.kyc_status || "verified",
          governorate: kycData.governorate || "",
          birth_date: kycData.birth_date || "",
          gender: kycData.gender || "",
          kyc_updated_at: new Date().toISOString()
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 16.1 Admin update KYC status (Approve / Reject) in Cloud RTDB
  async updateUserKYCStatus(phone, status, isVerified, notes = "") {
    try {
      const cleanPhone = (phone || "").replace(/[^0-9]/g, "");
      if (!cleanPhone) return false;
      const payload = {
        is_id_verified: !!isVerified,
        kyc_status: status,
        kyc_review_notes: notes || "",
        kyc_reviewed_at: new Date().toISOString()
      };
      if (status === "rejected" || !isVerified) {
        payload.national_id = null;
        payload.id_card_front = null;
        payload.id_card_back = null;
        payload.live_selfie_image = null;
        payload.national_id_image = null;
        payload.id_governorate = null;
        payload.id_birthdate = null;
        payload.id_gender = null;
        payload.match_score = null;
      }
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 17. Get all users for admin
  async getAllUsers() {
    try {
      const res = await fetch(`${this.url}/users.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        return Object.values(data);
      }
    } catch (e) {}
    return [];
  },

  // 18. Update order status in Cloud RTDB
  async updateOrderStatus(orderId, status, deliveredCode = null) {
    try {
      const patch = { status, is_read_by_admin: true };
      if (deliveredCode) patch.delivered_code = deliveredCode;
      const res = await fetch(`${this.url}/orders/${orderId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 18b. Update order read status by admin
  async updateOrderReadStatus(orderId, isRead = true) {
    try {
      const res = await fetch(`${this.url}/orders/${orderId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_read_by_admin: !!isRead })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 19. Get Wi-Fi cards from Cloud RTDB
  async getWiFiCards() {
    try {
      const res = await fetch(`${this.url}/wifi_cards.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        const arr = Array.isArray(data) ? data.filter(Boolean) : Object.values(data);
        return arr.map(c => ({
          ...c,
          card_id: c.card_id || c.id || Date.now(),
          is_used: !!c.is_used
        }));
      }
    } catch (e) {}
    return [];
  },

  // Save single Wi-Fi card to Cloud
  async saveWiFiCard(card) {
    try {
      const cid = card.card_id || Date.now();
      const res = await fetch(`${this.url}/wifi_cards/${cid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...card,
          card_id: cid,
          is_used: !!card.is_used,
          created_at: card.created_at || new Date().toISOString()
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Save batch Wi-Fi cards
  async saveWiFiCardsBatch(cardsArray) {
    if (!cardsArray || cardsArray.length === 0) return true;
    try {
      const patchObj = {};
      cardsArray.forEach((c, idx) => {
        const cid = c.card_id || (Date.now() + idx);
        patchObj[cid] = {
          ...c,
          card_id: cid,
          is_used: !!c.is_used,
          created_at: c.created_at || new Date().toISOString()
        };
      });
      const res = await fetch(`${this.url}/wifi_cards.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patchObj)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Delete Wi-Fi card
  async deleteWiFiCard(cardId) {
    try {
      const res = await fetch(`${this.url}/wifi_cards/${cardId}.json`, {
        method: "DELETE"
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Delete batch of Wi-Fi cards in a single network request
  async deleteWiFiCardsBatch(cardIds) {
    if (!cardIds || cardIds.length === 0) return true;
    try {
      const patchObj = {};
      cardIds.forEach(id => {
        patchObj[id] = null;
      });
      const res = await fetch(`${this.url}/wifi_cards.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patchObj)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // Delete all Wi-Fi cards (clear whole inventory)
  async deleteAllWiFiCards() {
    try {
      const res = await fetch(`${this.url}/wifi_cards.json`, {
        method: "DELETE"
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 20. Dispense Wi-Fi card with cloud persistence
  async dispenseWiFiCard(userPhone, criteria = {}) {
    try {
      const cards = await this.getWiFiCards();
      const cleanPhone = (userPhone || "").replace(/[^0-9]/g, "");
      
      // Target card type, product id or product code
      const rawType = (typeof criteria === "string" ? criteria : (criteria.card_type || "")).toUpperCase().trim();
      const targetPCode = ((typeof criteria === "object" ? criteria.product_code : "") || "").toUpperCase().trim();
      const targetPid = ((typeof criteria === "object" ? criteria.product_id : "") || "").toString().trim();

      // Normalize target type (e.g. 9 -> 1H, 10 -> 2H, 11 -> 7H)
      let targetType = rawType;
      if (rawType.includes("7") || targetPCode === "11" || targetPid === "11") targetType = "7H";
      else if (rawType.includes("2") || targetPCode === "10" || targetPid === "10") targetType = "2H";
      else if (rawType.includes("1") || targetPCode === "9" || targetPid === "9") targetType = "1H";

      // Find unused card matching criteria
      let availableCard = cards.find(c => {
        if (c.is_used) return false;
        const cType = (c.card_type || "").toUpperCase().trim();
        const cPCode = (c.product_code || "").toUpperCase().trim();
        
        if (targetType && (cType === targetType || cPCode === targetType || cPCode === `WIFI-${targetType}`)) return true;
        if (targetPCode && (cPCode === targetPCode || cType === targetPCode)) return true;
        if (targetPid && (cPCode === targetPid || cType === targetPid)) return true;
        return false;
      });

      // Fallback: match by card_type if broad
      if (!availableCard && targetType) {
        availableCard = cards.find(c => !c.is_used && (c.card_type || "").toUpperCase().includes(targetType));
      }

      // If still not found and no specific criteria, any unused card
      if (!availableCard && !targetType && !targetPCode) {
        availableCard = cards.find(c => !c.is_used);
      }

      if (!availableCard) {
        return null; // Out of stock! Do NOT generate fake random code!
      }

      // Mark existing card as used
      await fetch(`${this.url}/wifi_cards/${availableCard.card_id}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          is_used: true,
          used_by: cleanPhone,
          used_at: new Date().toISOString()
        })
      });

      return {
        card_id: availableCard.card_id,
        card_code: availableCard.card_code,
        card_type: availableCard.card_type,
        product_code: availableCard.product_code
      };
    } catch (e) {
      console.error("dispenseWiFiCard error:", e);
      return null;
    }
  },

  async dispenseMultipleWiFiCards(userPhone, criteria = {}, count = 1) {
    try {
      const cards = await this.getWiFiCards();
      const cleanPhone = (userPhone || "").replace(/[^0-9]/g, "");
      
      const rawType = (typeof criteria === "string" ? criteria : (criteria.card_type || "")).toUpperCase().trim();
      const targetPCode = ((typeof criteria === "object" ? criteria.product_code : "") || "").toUpperCase().trim();
      const targetPid = ((typeof criteria === "object" ? criteria.product_id : "") || "").toString().trim();

      // Normalize target type
      let targetType = rawType;
      if (rawType.includes("7") || targetPCode === "11" || targetPid === "11") targetType = "7H";
      else if (rawType.includes("2") || targetPCode === "10" || targetPid === "10") targetType = "2H";
      else if (rawType.includes("1") || targetPCode === "9" || targetPid === "9") targetType = "1H";

      // Find unused matching cards
      const availableCards = cards.filter(c => {
        if (c.is_used) return false;
        const cType = (c.card_type || "").toUpperCase().trim();
        const cPCode = (c.product_code || "").toUpperCase().trim();
        
        if (targetType && (cType === targetType || cPCode === targetType || cPCode === `WIFI-${targetType}`)) return true;
        if (targetPCode && (cPCode === targetPCode || cType === targetPCode)) return true;
        if (targetPid && (cPCode === targetPid || cType === targetPid)) return true;
        return false;
      });

      // If needed, fallback to broader search
      if (availableCards.length < count && targetType) {
        cards.forEach(c => {
          if (!c.is_used && !availableCards.some(a => a.card_id === c.card_id)) {
            if ((c.card_type || "").toUpperCase().includes(targetType)) {
              availableCards.push(c);
            }
          }
        });
      }

      if (availableCards.length < count) {
        return null; // Not enough cards in stock!
      }

      const pickedCards = availableCards.slice(0, count);
      const results = [];

      for (const card of pickedCards) {
        await fetch(`${this.url}/wifi_cards/${card.card_id}.json`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            is_used: true,
            used_by: cleanPhone,
            used_at: new Date().toISOString()
          })
        });

        results.push({
          card_id: card.card_id,
          card_code: card.card_code,
          card_type: card.card_type,
          product_code: card.product_code
        });
      }

      return results;
    } catch (e) {
      console.error("dispenseMultipleWiFiCards error:", e);
      return null;
    }
  },

  // 21. Welcome Bonus Configuration (هدية التسجيل للعملاء الجدد)
  async getWelcomeBonusConfig() {
    try {
      const res = await fetch(`${this.url}/system_settings/welcome_bonus.json`);
      if (res.ok) {
        const data = await res.json();
        if (data) return data;
      }
    } catch (e) {}
    return { enabled: false, amount: 0 };
  },

  async saveWelcomeBonusConfig(config) {
    try {
      const res = await fetch(`${this.url}/system_settings/welcome_bonus.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 22. Store Announcements & Promo Ads (شريط الأخبار وبوب اب الإعلان)
  async getStoreAnnouncements() {
    try {
      const res = await fetch(`${this.url}/store_announcements.json`);
      if (res.ok) {
        const data = await res.json();
        if (data) return data;
      }
    } catch (e) {}
    return null;
  },

  async updateStoreAnnouncements(data) {
    try {
      const res = await fetch(`${this.url}/store_announcements.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 23. Full APK Update Config (ملفات APK الأساسية - زي الريان)
  async getAppUpdateConfig() {
    try {
      const res = await fetch(`${this.url}/app_update.json?ts=${Date.now()}`);
      if (res.ok) return await res.json();
    } catch (e) {}
    return null;
  },

  async saveAppUpdateConfig(config) {
    try {
      const res = await fetch(`${this.url}/app_update.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 24. Tournaments & Gaming Competitions (دورات وبطولات الجوكر)
  async getNextTournamentId() {
    try {
      let lastId = 0;
      const res = await fetch(`${this.url}/counters/tournaments_last_id.json?ts=${Date.now()}`);
      if (res.ok) {
        const val = await res.json();
        if (typeof val === "number") lastId = val;
      }
      const existing = await this.getTournaments();
      if (Array.isArray(existing)) {
        for (const t of existing) {
          const tid = parseInt(t.id, 10);
          if (!isNaN(tid) && tid > lastId) lastId = tid;
        }
      }
      const nextId = lastId + 1;
      await fetch(`${this.url}/counters/tournaments_last_id.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(nextId)
      });
      return nextId;
    } catch (e) {
      return Date.now();
    }
  },

  async getTournaments() {
    try {
      const res = await fetch(`${this.url}/tournaments.json?ts=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        if (Array.isArray(data)) return data.filter(Boolean);
        return Object.values(data);
      }
    } catch (e) {}
    return [];
  },

  async saveTournament(tourney) {
    try {
      const tid = tourney.id || Date.now();
      const res = await fetch(`${this.url}/tournaments/${tid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(tourney)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async deleteTournament(tourneyId) {
    try {
      await fetch(`${this.url}/tournaments/${tourneyId}.json`, { method: "DELETE" });
      await fetch(`${this.url}/tournament_participants/${tourneyId}.json`, { method: "DELETE" });
      return true;
    } catch (e) {
      return false;
    }
  },

  async getTournamentParticipants(tourneyId) {
    try {
      const res = await fetch(`${this.url}/tournament_participants/${tourneyId}.json?ts=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        if (Array.isArray(data)) return data.filter(Boolean);
        return Object.values(data);
      }
    } catch (e) {}
    return [];
  },

  async addTournamentParticipant(tourneyId, participant) {
    try {
      const pid = participant.id || `p_${Date.now()}`;
      participant.id = pid;
      participant.created_at = new Date().toISOString();
      const res = await fetch(`${this.url}/tournament_participants/${tourneyId}/${pid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(participant)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async broadcastTournamentRoom(tourneyId, roomData) {
    try {
      // 1. Update tournament room details
      await fetch(`${this.url}/tournaments/${tourneyId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          room_id: roomData.room_id,
          room_password: roomData.room_password,
          room_notes: roomData.room_notes || ""
        })
      });

      // 2. Fetch all participants to create order notifications
      const participants = await this.getTournamentParticipants(tourneyId);
      for (const p of participants) {
        const orderId = `tourney_room_${tourneyId}_${p.user_id}_${Date.now()}`;
        const orderPayload = {
          order_id: orderId,
          user_id: p.user_id,
          phone_number: p.phone_number,
          player_id: p.pubg_id || "",
          product_name: `🎮 بيانات روم البطولة: ${roomData.tournament_title || 'بطولة الجوكر'}`,
          product_price: 0,
          product_category: "TournamentRoom",
          payment_method: "بطولة الجوكر الرسمية",
          room_id: roomData.room_id,
          room_password: roomData.room_password,
          room_notes: roomData.room_notes || "",
          delivered_code: `رقم الروم (ID): ${roomData.room_id} | كلمة السر (PASS): ${roomData.room_password}`,
          status: "مكتمل",
          created_at: new Date().toISOString()
        };
        await this.createOrder(orderPayload);
      }
      return true;
    } catch (e) {
      return false;
    }
  },

  async updateTournamentFixtures(tourneyId, fixtures) {
    try {
      const res = await fetch(`${this.url}/tournaments/${tourneyId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fixtures })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async updateTournamentHallOfFame(tourneyId, hallOfFame) {
    try {
      const res = await fetch(`${this.url}/tournaments/${tourneyId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          hall_of_fame: hallOfFame,
          status: "completed"
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async updateTournamentLinks(tourneyId, links) {
    try {
      const res = await fetch(`${this.url}/tournaments/${tourneyId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stream_url: links.stream_url || "",
          group_link: links.group_link || ""
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  // 25. 1v1 Match Challenges (مبارزات التحدي 1 ضد 1)
  async getChallenges() {
    try {
      const res = await fetch(`${this.url}/challenges.json?ts=${Date.now()}`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        if (Array.isArray(data)) return data.filter(Boolean);
        return Object.values(data);
      }
    } catch (e) {}
    return [];
  },

  async saveChallenge(challenge) {
    try {
      const cid = challenge.id || `c_${Date.now()}`;
      challenge.id = cid;
      challenge.created_at = challenge.created_at || new Date().toISOString();
      const res = await fetch(`${this.url}/challenges/${cid}.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(challenge)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async updateChallenge(challengeId, patchData) {
    try {
      const res = await fetch(`${this.url}/challenges/${challengeId}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patchData)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async markUserAsChampion(phone, title) {
    try {
      const cleanPhone = String(phone).replace(/\D/g, "");
      const userRes = await fetch(`${this.url}/users/${cleanPhone}.json`);
      let user = null;
      if (userRes.ok) user = await userRes.json();
      
      const titles = (user && Array.isArray(user.champion_titles)) ? user.champion_titles : [];
      if (title && !titles.includes(title)) titles.push(title);

      await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          is_tournament_champion: true,
          champion_titles: titles
        })
      });
      return true;
    } catch (e) {
      return false;
    }
  },

  async updateUserProfile(phone, { name, profile_photo }) {
    try {
      const cleanPhone = String(phone || "").replace(/\D/g, "");
      if (!cleanPhone) return false;
      const updates = { updated_at: new Date().toISOString() };
      if (name) {
        updates.name = name;
        updates.username = name;
      }
      if (profile_photo) {
        updates.profile_photo = profile_photo;
        updates.avatar = profile_photo;
      }
      const res = await fetch(`${this.url}/users/${cleanPhone}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async updateTournamentParticipantTeam(tourneyId, userId, newTeam) {
    try {
      const parts = await this.getTournamentParticipants(tourneyId);
      const target = parts.find(p => String(p.user_id) === String(userId));
      if (!target) return false;
      const partKey = target._key || target.id;
      const res = await fetch(`${this.url}/tournaments/${tourneyId}/participants/${partKey}.json`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          chosen_teams: newTeam,
          selected_team: newTeam.id || newTeam.team_id || newTeam,
          selected_team_name: newTeam.name || newTeam.team_name || newTeam,
          selected_team_logo: newTeam.logo || "",
          updated_at: new Date().toISOString()
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async getStoreCommissionPercent() {
    try {
      const res = await fetch(`${this.url}/store_settings/commission_percent.json`);
      if (res.ok) {
        const val = await res.json();
        return (val !== null && !isNaN(parseFloat(val))) ? parseFloat(val) : 5;
      }
      return 5;
    } catch (e) {
      return 5;
    }
  },

  async saveStoreCommissionPercent(percent) {
    try {
      const p = parseFloat(percent) || 0;
      const res = await fetch(`${this.url}/store_settings/commission_percent.json`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(p)
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async logStoreRevenue(record) {
    try {
      const res = await fetch(`${this.url}/store_revenues.json`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...record,
          created_at: new Date().toISOString()
        })
      });
      return res.ok;
    } catch (e) {
      return false;
    }
  },

  async getStoreRevenues() {
    try {
      const res = await fetch(`${this.url}/store_revenues.json`);
      if (res.ok) {
        const data = await res.json();
        if (!data) return [];
        return Object.keys(data).map(k => ({ _id: k, ...data[k] })).reverse();
      }
      return [];
    } catch (e) {
      return [];
    }
  }
};

window.firebaseService = firebaseService;

